import crypto from "node:crypto";
import fs from "node:fs";
import mysql, { type ResultSetHeader, type RowDataPacket } from "mysql2/promise";
import { parseHopiInformeExport } from "../server/lib/hopiInforme";
import { writeAttendanceSnapshot, writeRevenueSnapshot } from "../server/lib/hopiInformeImport";

const sourceFile = process.argv[2];
if (!sourceFile) throw new Error("usage: tsx scripts/import-hopi-informe-export.mts <chat-file>");
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");

const CHANNEL_GROUPS: Record<string, string> = {
  "A & B": "Alimentos & Bebidas", MERC: "Mercadorias", PLAKA: "Mercadorias", SERV: "Serviços do parque",
  "HOPI NIVER": "Serviços do parque", BILHETERIA: "Ingressos", "E-COMMERCE": "Ingressos",
  TLMKT: "Ingressos", AGVT: "Ingressos", TURISMO: "Ingressos", PARCEIROS: "Ingressos",
  EMPRESA: "B2B & Grupos", EVENTOS: "B2B & Grupos", "ESCOLA PARTICULAR": "B2B & Grupos", "ESCOLA PUBLICA": "B2B & Grupos",
};
const INTERNAL_CHANNELS = new Set(["A & B", "MERC", "SERV", "PLAKA"]);
const sourceKey = "whatsapp-hopi-informe-export";
const raw = fs.readFileSync(sourceFile, "utf8");
const contentHash = crypto.createHash("sha256").update(raw).digest("hex");
const parsed = parseHopiInformeExport(raw);
const parseWarningCount = parsed.warnings.length;
const connection = await mysql.createConnection(process.env.DATABASE_URL);

try {
  await connection.execute(
    `INSERT INTO operational_sources (source_key, source_type, name, external_id, source_url)
     VALUES (?, 'operational_message', ?, ?, ?)
     ON DUPLICATE KEY UPDATE name = VALUES(name), external_id = VALUES(external_id), source_url = VALUES(source_url), active = 1`,
    [sourceKey, "Hopi Informe WhatsApp export", contentHash, "https://chat.whatsapp.com/"],
  );
  const [sourceRows] = await connection.execute<RowDataPacket[]>("SELECT id FROM operational_sources WHERE source_key = ? LIMIT 1", [sourceKey]);
  const sourceId = Number(sourceRows[0].id);
  const [existing] = await connection.execute<RowDataPacket[]>("SELECT id, status FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1", [sourceId, contentHash]);
  if (existing[0]?.status === "completed") {
    console.log(JSON.stringify({ status: "skipped", reason: "content_hash_already_imported", sourceKey, contentHash }));
    process.exit(0);
  }
  await connection.execute(
    `INSERT INTO operational_import_runs (source_id, content_hash, status, warnings_json)
     VALUES (?, ?, 'started', ?)
     ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), status = 'started', rows_seen = 0, rows_inserted = 0,
       rows_updated = 0, rows_rejected = 0, warnings_json = VALUES(warnings_json), completed_at = NULL`,
    [sourceId, contentHash, JSON.stringify(parsed.warnings)],
  );
  const [runRows] = await connection.execute<RowDataPacket[]>("SELECT id FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1", [sourceId, contentHash]);
  const runId = Number(runRows[0].id);
  let rowsSeen = 0, rowsInserted = 0, rowsUpdated = 0;
  let rowsPreserved = 0;
  await connection.beginTransaction();
  try {
    for (const point of parsed.revenue) {
      rowsSeen += 1;
      const snapshot = await writeRevenueSnapshot(connection, point, runId, sourceKey);
      if (snapshot.status === "preserved") {
        rowsPreserved += 1;
        parsed.warnings.push(`${point.observedAt}:preserved_existing_source:${snapshot.existingSourceKey}`);
        continue;
      }
      snapshot.status === "inserted" ? rowsInserted++ : rowsUpdated++;
      const snapshotId = snapshot.snapshotId!;
      for (const [channel, revenueCents] of Object.entries(point.channels)) {
        rowsSeen += 1;
        const classification = INTERNAL_CHANNELS.has(channel) ? "internal" : "external";
        await connection.execute(
          `INSERT INTO revenue_channels (code, label, business_group, classification)
           VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE label = VALUES(label), business_group = VALUES(business_group), classification = VALUES(classification), active = 1`,
          [channel, channel, CHANNEL_GROUPS[channel] ?? "Outros", classification],
        );
        const [channelRows] = await connection.execute<RowDataPacket[]>("SELECT id FROM revenue_channels WHERE code = ? LIMIT 1", [channel]);
        const [detail] = await connection.execute<ResultSetHeader>(
          `INSERT INTO revenue_channel_snapshots (snapshot_id, channel_id, revenue_cents, source_run_id)
           VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE revenue_cents = VALUES(revenue_cents), source_run_id = VALUES(source_run_id)`,
          [snapshotId, Number(channelRows[0].id), revenueCents, runId],
        );
        detail.affectedRows === 1 ? rowsInserted++ : rowsUpdated++;
      }
    }
    for (const point of parsed.attendance) {
      rowsSeen += 1;
      const result = await writeAttendanceSnapshot(connection, point, runId, sourceKey);
      if (result.status === "preserved") {
        rowsPreserved += 1;
        parsed.warnings.push(`${point.observedAt}:preserved_existing_source:${result.existingSourceKey}`);
        continue;
      }
      result.status === "inserted" ? rowsInserted++ : rowsUpdated++;
    }
    await connection.execute(
      `UPDATE operational_import_runs SET status = 'completed', rows_seen = ?, rows_inserted = ?, rows_updated = ?,
       rows_rejected = ?, warnings_json = ?, completed_at = NOW() WHERE id = ?`,
      [rowsSeen, rowsInserted, rowsUpdated, parseWarningCount, JSON.stringify(parsed.warnings), runId],
    );
    await connection.commit();
    console.log(JSON.stringify({ status: "completed", sourceKey, contentHash, revenueSnapshots: parsed.revenue.length, attendanceSnapshots: parsed.attendance.length, rowsSeen, rowsInserted, rowsUpdated, rowsPreserved, rowsRejected: parseWarningCount, warnings: parsed.warnings }));
  } catch (error) {
    await connection.rollback();
    await connection.execute("UPDATE operational_import_runs SET status = 'failed', warnings_json = ?, completed_at = NOW() WHERE id = ?", [JSON.stringify([error instanceof Error ? error.message.slice(0, 500) : "unknown_import_error"]), runId]);
    throw error;
  }
} finally {
  await connection.end();
}
