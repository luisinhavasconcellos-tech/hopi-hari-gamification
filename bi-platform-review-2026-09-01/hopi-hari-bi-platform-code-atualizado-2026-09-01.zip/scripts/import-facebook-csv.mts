import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import mysql from "mysql2/promise";
import type { Connection, ResultSetHeader, RowDataPacket } from "mysql2/promise";
import { parseFacebookBundle } from "../server/lib/facebookCsv";

const ROOT = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const SOURCE_KEY = "facebook-csv-export-2026-08";
const SOURCE_NAME = "Facebook Insights CSV export";

type Stats = { rowsSeen: number; rowsInserted: number; rowsUpdated: number; rowsUnchanged: number; rowsRejected: number; warnings: string[] };

function sha256(files: string[]) {
  const hash = crypto.createHash("sha256");
  for (const file of files) hash.update(fs.readFileSync(file));
  return hash.digest("hex");
}

function countOutcome(stats: Stats, result: ResultSetHeader) {
  if (result.affectedRows === 1) stats.rowsInserted += 1;
  else if (result.affectedRows === 2) stats.rowsUpdated += 1;
  else stats.rowsUnchanged += 1;
}

async function ensureSource(connection: Connection) {
  await connection.execute(
    `INSERT INTO operational_sources (source_key, source_type, name, external_id, source_url)
     VALUES (?, 'manual', ?, ?, NULL)
     ON DUPLICATE KEY UPDATE name = VALUES(name), active = 1`,
    [SOURCE_KEY, SOURCE_NAME, SOURCE_KEY],
  );
  const [rows] = await connection.execute<RowDataPacket[]>("SELECT id FROM operational_sources WHERE source_key = ? LIMIT 1", [SOURCE_KEY]);
  return Number(rows[0].id);
}

async function beginRun(connection: Connection, sourceId: number, contentHash: string) {
  const [existing] = await connection.execute<RowDataPacket[]>(
    "SELECT id, status FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1",
    [sourceId, contentHash],
  );
  if (existing[0]?.status === "completed") return { id: Number(existing[0].id), skipped: true };
  await connection.execute(
    `INSERT INTO operational_import_runs (source_id, content_hash, status)
     VALUES (?, ?, 'started')
     ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), status = 'started', rows_seen = 0, rows_inserted = 0,
       rows_updated = 0, rows_rejected = 0, warnings_json = NULL, completed_at = NULL`,
    [sourceId, contentHash],
  );
  const [rows] = await connection.execute<RowDataPacket[]>("SELECT LAST_INSERT_ID() AS id");
  return { id: Number(rows[0].id), skipped: false };
}

async function completeRun(connection: Connection, runId: number, stats: Stats) {
  await connection.execute(
    `UPDATE operational_import_runs
     SET status = 'completed', rows_seen = ?, rows_inserted = ?, rows_updated = ?, rows_rejected = ?, warnings_json = ?, completed_at = NOW()
     WHERE id = ?`,
    [stats.rowsSeen, stats.rowsInserted, stats.rowsUpdated, stats.rowsRejected, JSON.stringify(stats.warnings), runId],
  );
}

function defaultFiles() {
  const upload = "/home/ubuntu/upload";
  return {
    followers: path.join(upload, "Seguidores(1).csv"),
    linkClicks: path.join(upload, "Cliquesnolink.csv"),
    interactions: path.join(upload, "Interações.csv"),
    visits: path.join(upload, "Visitas.csv"),
    views: path.join(upload, "Visualizações.csv"),
    viewers: path.join(upload, "Visualizadores.csv"),
    demographics: path.join(upload, "Público(1).csv"),
  };
}

async function main() {
  const files = defaultFiles();
  const fileList = Object.values(files);
  for (const file of fileList) if (!fs.existsSync(file)) throw new Error(`missing_input:${path.basename(file)}`);
  const bundle = parseFacebookBundle(files);
  const connection = await mysql.createConnection(process.env.DATABASE_URL!);
  const stats: Stats = { rowsSeen: 0, rowsInserted: 0, rowsUpdated: 0, rowsUnchanged: 0, rowsRejected: 0, warnings: [] };
  try {
    await connection.beginTransaction();
    const sourceId = await ensureSource(connection);
    const run = await beginRun(connection, sourceId, sha256(fileList));
    if (run.skipped) {
      await connection.commit();
      console.log(JSON.stringify({ status: "skipped", sourceKey: SOURCE_KEY, runId: run.id, reason: "content_hash_already_completed" }));
      return;
    }
    const metricMaps = {
      followers: new Map(bundle.daily.followers.map(row => [row.observedDate, row.value])),
      linkClicks: new Map(bundle.daily.linkClicks.map(row => [row.observedDate, row.value])),
      interactions: new Map(bundle.daily.interactions.map(row => [row.observedDate, row.value])),
      visits: new Map(bundle.daily.visits.map(row => [row.observedDate, row.value])),
      views: new Map(bundle.daily.views.map(row => [row.observedDate, row.value])),
      viewers: new Map(bundle.daily.viewers.map(row => [row.observedDate, row.value])),
    };
    const dates = [...new Set(Object.values(metricMaps).flatMap(map => [...map.keys()]))].sort();
    for (const observedDate of dates) {
      stats.rowsSeen += 1;
      const [result] = await connection.execute<ResultSetHeader>(
        `INSERT INTO facebook_daily_metrics
          (observed_date, followers, link_clicks, interactions, visits, views, viewers, source_run_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE followers = VALUES(followers), link_clicks = VALUES(link_clicks), interactions = VALUES(interactions),
           visits = VALUES(visits), views = VALUES(views), viewers = VALUES(viewers), source_run_id = VALUES(source_run_id)`,
        [observedDate, metricMaps.followers.get(observedDate) ?? null, metricMaps.linkClicks.get(observedDate) ?? null, metricMaps.interactions.get(observedDate) ?? null, metricMaps.visits.get(observedDate) ?? null, metricMaps.views.get(observedDate) ?? null, metricMaps.viewers.get(observedDate) ?? null, run.id],
      );
      countOutcome(stats, result);
    }
    const [demographicResult] = await connection.execute<ResultSetHeader>(
      `INSERT INTO facebook_demographics (observed_date, demographics_json, source_run_id)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE demographics_json = VALUES(demographics_json), source_run_id = VALUES(source_run_id)`,
      [bundle.demographics.observedDate, JSON.stringify(bundle.demographics.demographics), run.id],
    );
    stats.rowsSeen += 1;
    countOutcome(stats, demographicResult);
    await completeRun(connection, run.id, stats);
    await connection.commit();
    console.log(JSON.stringify({ status: "completed", sourceKey: SOURCE_KEY, runId: run.id, observedDateFrom: dates[0], observedDateTo: dates.at(-1), dailyRows: dates.length, demographicsDate: bundle.demographics.observedDate, ...stats }));
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    await connection.end();
  }
}

main().catch(error => {
  console.error(error instanceof Error ? error.message : "facebook_import_failed");
  process.exit(1);
});
