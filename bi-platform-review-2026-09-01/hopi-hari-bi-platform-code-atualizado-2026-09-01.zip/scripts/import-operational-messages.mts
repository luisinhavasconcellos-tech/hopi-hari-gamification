import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import mysql, { type ResultSetHeader } from "mysql2/promise";

type RevenuePoint = {
  observedAt: string;
  internalRevenueCents: number;
  externalRevenueCents: number;
  grossRevenueCents: number;
  internalPerCapitaCents: number;
  channels: Record<string, number>;
};

type AttendancePoint = {
  observedAt: string;
  publicCount: number;
  payingCount: number;
  complimentaryCount: number;
  entriesInterval: number;
  exitsInterval: number;
  currentlyInPark: number;
};

type Payload = {
  sourceKey: string;
  businessDate: string;
  timezone: string;
  revenue: RevenuePoint[];
  attendance: AttendancePoint[];
};

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SOURCE_FILE = path.join(ROOT, "data", "operational", "2026-08-27.json");
const INTERNAL_CHANNELS = new Set(["A & B", "MERC", "SERV", "PLAKA"]);
const CHANNEL_GROUPS: Record<string, string> = {
  "A & B": "Alimentos & Bebidas",
  MERC: "Mercadorias",
  PLAKA: "Mercadorias",
  SERV: "Serviços do parque",
  "HOPI NIVER": "Serviços do parque",
  BILHETERIA: "Ingressos",
  "E-COMMERCE": "Ingressos",
  TLMKT: "Ingressos",
  AGVT: "Ingressos",
  TURISMO: "Ingressos",
  PARCEIROS: "Ingressos",
  EMPRESA: "B2B & Grupos",
  EVENTOS: "B2B & Grupos",
  "ESCOLA PARTICULAR": "B2B & Grupos",
  "ESCOLA PUBLICA": "B2B & Grupos"
};

function sha256(value: string) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function assertInteger(name: string, value: number) {
  if (!Number.isSafeInteger(value) || value < 0) throw new Error(`${name}:invalid_nonnegative_integer`);
}

export function validatePayload(payload: Payload) {
  if (payload.timezone !== "America/Sao_Paulo") throw new Error("timezone_must_be_America_Sao_Paulo");
  for (const point of payload.revenue) {
    Object.entries(point.channels).forEach(([channel, cents]) => assertInteger(`channel:${channel}`, cents));
    const gross = Object.values(point.channels).reduce((sum, cents) => sum + cents, 0);
    const internal = Object.entries(point.channels)
      .filter(([channel]) => INTERNAL_CHANNELS.has(channel))
      .reduce((sum, [, cents]) => sum + cents, 0);
    const external = gross - internal;
    if (gross !== point.grossRevenueCents) throw new Error(`${point.observedAt}:gross_total_mismatch`);
    if (internal !== point.internalRevenueCents) throw new Error(`${point.observedAt}:internal_total_mismatch`);
    if (external !== point.externalRevenueCents) throw new Error(`${point.observedAt}:external_total_mismatch`);
    assertInteger(`${point.observedAt}:per_capita`, point.internalPerCapitaCents);
  }

  for (const point of payload.attendance) {
    const fields = [
      point.publicCount,
      point.payingCount,
      point.complimentaryCount,
      point.entriesInterval,
      point.exitsInterval,
      point.currentlyInPark,
    ];
    fields.forEach((value, index) => assertInteger(`${point.observedAt}:attendance:${index}`, value));
    if (point.payingCount + point.complimentaryCount !== point.publicCount) {
      throw new Error(`${point.observedAt}:public_composition_mismatch`);
    }
  }
}

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const raw = fs.readFileSync(SOURCE_FILE, "utf8");
  const payload = JSON.parse(raw) as Payload;
  validatePayload(payload);

  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  try {
    await connection.execute(
      `INSERT INTO operational_sources (source_key, source_type, name)
       VALUES (?, 'operational_message', 'Hopi Hari operational revenue and attendance feed')
       ON DUPLICATE KEY UPDATE name = VALUES(name), active = 1`,
      [payload.sourceKey],
    );
    const [sourceRows] = await connection.execute<mysql.RowDataPacket[]>(
      "SELECT id FROM operational_sources WHERE source_key = ? LIMIT 1",
      [payload.sourceKey],
    );
    const sourceId = Number(sourceRows[0].id);
    const contentHash = sha256(raw);
    const [existingRuns] = await connection.execute<mysql.RowDataPacket[]>(
      "SELECT id, status FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1",
      [sourceId, contentHash],
    );
    if (existingRuns[0]?.status === "completed") {
      console.log(JSON.stringify({ status: "skipped", reason: "content_hash_already_imported" }));
      return;
    }

    await connection.execute(
      `INSERT INTO operational_import_runs (source_id, content_hash, status)
       VALUES (?, ?, 'started')
       ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), status = 'started', rows_seen = 0,
         rows_inserted = 0, rows_updated = 0, rows_rejected = 0, warnings_json = NULL, completed_at = NULL`,
      [sourceId, contentHash],
    );
    const [runRows] = await connection.execute<mysql.RowDataPacket[]>(
      "SELECT id FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1",
      [sourceId, contentHash],
    );
    const runId = Number(runRows[0].id);
    let inserted = 0;
    let updated = 0;
    let seen = 0;

    await connection.beginTransaction();
    try {
      for (const point of payload.revenue) {
        seen += 1;
        const observedAt = new Date(point.observedAt);
        const hour = Number(point.observedAt.slice(11, 13));
        const [snapshotResult] = await connection.execute<ResultSetHeader>(
          `INSERT INTO revenue_snapshots
            (observed_at, business_date, local_hour, internal_revenue_cents, external_revenue_cents,
             gross_revenue_cents, internal_per_capita_cents, source_run_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), business_date = VALUES(business_date),
             local_hour = VALUES(local_hour), internal_revenue_cents = VALUES(internal_revenue_cents),
             external_revenue_cents = VALUES(external_revenue_cents), gross_revenue_cents = VALUES(gross_revenue_cents),
             internal_per_capita_cents = VALUES(internal_per_capita_cents), source_run_id = VALUES(source_run_id)`,
          [observedAt, payload.businessDate, hour, point.internalRevenueCents, point.externalRevenueCents,
            point.grossRevenueCents, point.internalPerCapitaCents, runId],
        );
        const snapshotId = snapshotResult.insertId;
        snapshotResult.affectedRows === 1 ? inserted++ : updated++;

        for (const [channel, revenueCents] of Object.entries(point.channels)) {
          seen += 1;
          const classification = INTERNAL_CHANNELS.has(channel) ? "internal" : "external";
          await connection.execute(
            `INSERT INTO revenue_channels (code, label, business_group, classification)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE label = VALUES(label), business_group = VALUES(business_group),
               classification = VALUES(classification), active = 1`,
            [channel, channel, CHANNEL_GROUPS[channel] ?? "Outros", classification],
          );
          const [channelRows] = await connection.execute<mysql.RowDataPacket[]>(
            "SELECT id FROM revenue_channels WHERE code = ? LIMIT 1",
            [channel],
          );
          const [detailResult] = await connection.execute<ResultSetHeader>(
            `INSERT INTO revenue_channel_snapshots (snapshot_id, channel_id, revenue_cents, source_run_id)
             VALUES (?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE revenue_cents = VALUES(revenue_cents), source_run_id = VALUES(source_run_id)`,
            [snapshotId, Number(channelRows[0].id), revenueCents, runId],
          );
          detailResult.affectedRows === 1 ? inserted++ : updated++;
        }
      }

      for (const point of payload.attendance) {
        seen += 1;
        const observedAt = new Date(point.observedAt);
        const hour = Number(point.observedAt.slice(11, 13));
        const [result] = await connection.execute<ResultSetHeader>(
          `INSERT INTO attendance_snapshots
            (observed_at, business_date, local_hour, public_count, paying_count, complimentary_count,
             entries_interval, exits_interval, currently_in_park, source_run_id)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE business_date = VALUES(business_date), local_hour = VALUES(local_hour),
             public_count = VALUES(public_count), paying_count = VALUES(paying_count),
             complimentary_count = VALUES(complimentary_count), entries_interval = VALUES(entries_interval),
             exits_interval = VALUES(exits_interval), currently_in_park = VALUES(currently_in_park),
             source_run_id = VALUES(source_run_id)`,
          [observedAt, payload.businessDate, hour, point.publicCount, point.payingCount,
            point.complimentaryCount, point.entriesInterval, point.exitsInterval, point.currentlyInPark, runId],
        );
        result.affectedRows === 1 ? inserted++ : updated++;
      }

      await connection.execute(
        `UPDATE operational_import_runs SET status = 'completed', rows_seen = ?, rows_inserted = ?,
          rows_updated = ?, rows_rejected = 0, warnings_json = '[]', completed_at = NOW() WHERE id = ?`,
        [seen, inserted, updated, runId],
      );
      await connection.commit();
      console.log(JSON.stringify({ status: "completed", rowsSeen: seen, rowsInserted: inserted, rowsUpdated: updated }));
    } catch (error) {
      await connection.rollback();
      await connection.execute(
        "UPDATE operational_import_runs SET status = 'failed', warnings_json = ?, completed_at = NOW() WHERE id = ?",
        [JSON.stringify([error instanceof Error ? error.message.slice(0, 500) : "unknown_import_error"]), runId],
      );
      throw error;
    }
  } finally {
    await connection.end();
  }
}

await main();
