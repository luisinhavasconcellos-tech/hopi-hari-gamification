import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { execFileSync } from "node:child_process";
import mysql from "mysql2/promise";
import type { Connection, ResultSetHeader, RowDataPacket } from "mysql2/promise";
import { parseAudienceXlsx, parseFollowersXlsx, parseFollowerActivityXlsx, parseOverviewCsv, parseViewersCsv } from "../server/lib/tiktokExport";

type Stats = { rowsSeen: number; rowsInserted: number; rowsUpdated: number; rowsUnchanged: number; rowsRejected: number; warnings: string[] };
const SOURCE_KEY = "tiktok-export-2025-08-28";
const SOURCE_NAME = "TikTok export — Hopi Hari";
const upload = "/home/ubuntu/upload";
const inputs = [
  path.join(upload, "Overview_2025-08-28_1787841428_hopihari.zip"),
  path.join(upload, "Viewers_hopihari(2).zip"),
  path.join(upload, "Followers_hopihari(2).zip"),
];

function hashInputs() {
  const hash = crypto.createHash("sha256");
  for (const file of inputs) hash.update(fs.readFileSync(file));
  return hash.digest("hex");
}
function extract(zip: string, name: string, dir: string) {
  return execFileSync("unzip", ["-p", zip, name], { encoding: null, maxBuffer: 25 * 1024 * 1024 });
}
function countOutcome(stats: Stats, result: ResultSetHeader) {
  if (result.affectedRows === 1) stats.rowsInserted += 1;
  else if (result.affectedRows === 2) stats.rowsUpdated += 1;
  else stats.rowsUnchanged += 1;
}
async function ensureSource(connection: Connection) {
  await connection.execute(
    `INSERT INTO operational_sources (source_key, source_type, name, external_id, source_url)
     VALUES (?, 'manual', ?, ?, NULL)
     ON DUPLICATE KEY UPDATE name = VALUES(name), active = 1`,
    [SOURCE_KEY, SOURCE_NAME, SOURCE_KEY],
  );
  const [rows] = await connection.execute<RowDataPacket[]>("SELECT id FROM operational_sources WHERE source_key = ? LIMIT 1", [SOURCE_KEY]);
  return Number(rows[0].id);
}
async function beginRun(connection: Connection, sourceId: number, contentHash: string) {
  const [existing] = await connection.execute<RowDataPacket[]>("SELECT id, status FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1", [sourceId, contentHash]);
  if (existing[0]?.status === "completed") return { id: Number(existing[0].id), skipped: true };
  await connection.execute(
    `INSERT INTO operational_import_runs (source_id, content_hash, status)
     VALUES (?, ?, 'started')
     ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), status = 'started', rows_seen = 0, rows_inserted = 0, rows_updated = 0, rows_rejected = 0, warnings_json = NULL, completed_at = NULL`,
    [sourceId, contentHash],
  );
  const [rows] = await connection.execute<RowDataPacket[]>("SELECT LAST_INSERT_ID() AS id");
  return { id: Number(rows[0].id), skipped: false };
}
async function completeRun(connection: Connection, runId: number, stats: Stats) {
  await connection.execute(
    `UPDATE operational_import_runs SET status = 'completed', rows_seen = ?, rows_inserted = ?, rows_updated = ?, rows_rejected = ?, warnings_json = ?, completed_at = NOW() WHERE id = ?`,
    [stats.rowsSeen, stats.rowsInserted, stats.rowsUpdated, stats.rowsRejected, JSON.stringify(stats.warnings), runId],
  );
}
export async function runTiktokImport() {
  for (const file of inputs) if (!fs.existsSync(file)) throw new Error(`missing_input:${path.basename(file)}`);
  const workspace = fs.mkdtempSync(path.join(os.tmpdir(), "tiktok-export-"));
  const overview = parseOverviewCsv(extract(inputs[0], "Overview.csv", workspace).toString("utf8"), "Overview_2025-08-28");
  const viewers = parseViewersCsv(extract(inputs[1], "Viewers.csv", workspace).toString("utf8"), "Viewers_2025-08-28");
  const followersBuffer = extract(inputs[2], "FollowerHistory.xlsx", workspace);
  const activityBuffer = extract(inputs[2], "FollowerActivity.xlsx", workspace);
  const audienceBuffer = Buffer.from(extract(inputs[2], "FollowerGender.xlsx", workspace));
  const territoriesBuffer = Buffer.from(extract(inputs[2], "FollowerTopTerritories.xlsx", workspace));
  const followerHistory = parseFollowersXlsx(followersBuffer, "Followers_2025-08-28");
  const activity = parseFollowerActivityXlsx(activityBuffer, "FollowerActivity_2026-08-29");
  const gender = parseAudienceXlsx(audienceBuffer, territoriesBuffer);
  const followerByDate = new Map(followerHistory.map(row => [row.observedDate, row.followers]));
  const overviewByDate = new Map(overview.map(row => [row.observedDate, row]));
  const dates = [...new Set([...overview.map(row => row.observedDate), ...followerHistory.map(row => row.observedDate)])].sort();
  const connection = await mysql.createConnection(process.env.DATABASE_URL!);
  const stats: Stats = { rowsSeen: 0, rowsInserted: 0, rowsUpdated: 0, rowsUnchanged: 0, rowsRejected: 0, warnings: [] };
  if (viewers.some(row => row.totalViewers === null)) stats.warnings.push("viewers:undefined_total_preserved_as_null");
  try {
    await connection.beginTransaction();
    const sourceId = await ensureSource(connection);
    const run = await beginRun(connection, sourceId, hashInputs());
    if (run.skipped) {
      await connection.commit();
      const skippedResult = { status: "skipped", sourceKey: SOURCE_KEY, runId: run.id, reason: "content_hash_already_completed" } as const;
      console.log(JSON.stringify(skippedResult));
      return skippedResult;
    }
    for (const observedDate of dates) {
      const row = overviewByDate.get(observedDate);
      stats.rowsSeen += 1;
      const [result] = await connection.execute<ResultSetHeader>(
        `INSERT INTO tiktok_daily_metrics (observed_date, followers, video_views, profile_views, likes, comments, shares, source_run_id)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE followers = VALUES(followers), video_views = VALUES(video_views), profile_views = VALUES(profile_views), likes = VALUES(likes), comments = VALUES(comments), shares = VALUES(shares), source_run_id = VALUES(source_run_id)`,
        [observedDate, followerByDate.get(observedDate) ?? null, row?.videoViews ?? null, row?.profileViews ?? null, row?.likes ?? null, row?.comments ?? null, row?.shares ?? null, run.id],
      );
      countOutcome(stats, result);
    }
    for (const row of viewers) {
      stats.rowsSeen += 1;
      const [result] = await connection.execute<ResultSetHeader>(
        `INSERT INTO tiktok_viewer_snapshots (observed_date, total_viewers, new_viewers, returning_viewers, source_run_id)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE total_viewers = VALUES(total_viewers), new_viewers = VALUES(new_viewers), returning_viewers = VALUES(returning_viewers), source_run_id = VALUES(source_run_id)`,
        [row.observedDate, row.totalViewers, row.newViewers, row.returningViewers, run.id],
      );
      countOutcome(stats, result);
    }
    const audienceDate = activity.at(-1)?.observedDate ?? followerHistory.at(-1)?.observedDate;
    if (!audienceDate) throw new Error("tiktok_missing_audience_date");
    stats.rowsSeen += 1;
    const [audienceResult] = await connection.execute<ResultSetHeader>(
      `INSERT INTO tiktok_audience_snapshots (observed_date, demographics_json, source_run_id) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE demographics_json = VALUES(demographics_json), source_run_id = VALUES(source_run_id)`,
      [audienceDate, JSON.stringify(gender), run.id],
    );
    countOutcome(stats, audienceResult);
    for (const row of activity) {
      stats.rowsSeen += 1;
      const [result] = await connection.execute<ResultSetHeader>(
        `INSERT INTO tiktok_follower_activity (observed_date, hour, active_followers, source_run_id) VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE active_followers = VALUES(active_followers), source_run_id = VALUES(source_run_id)`,
        [row.observedDate, row.hour, row.activeFollowers, run.id],
      );
      countOutcome(stats, result);
    }
    await completeRun(connection, run.id, stats);
    await connection.commit();
    const completedResult = { status: "completed", sourceKey: SOURCE_KEY, runId: run.id, dailyRows: dates.length, viewerRows: viewers.length, activityRows: activity.length, audienceDate, ...stats };
    console.log(JSON.stringify(completedResult));
    return completedResult;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    await connection.end();
    fs.rmSync(workspace, { recursive: true, force: true });
  }
}
if (import.meta.url === `file://${process.argv[1]}`) {
  runTiktokImport().catch(error => { console.error(error instanceof Error ? error.message : "tiktok_import_failed"); process.exit(1); });
}
