import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import mysql, { type Connection, type ResultSetHeader } from "mysql2/promise";
import XLSX from "xlsx";

type Cell = string | number | boolean | Date | null | undefined;
type Row = Cell[];

type ImportStats = {
  sourceKey: string;
  status: "completed" | "skipped";
  rowsSeen: number;
  rowsInserted: number;
  rowsUpdated: number;
  rowsRejected: number;
  warnings: string[];
};

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const SOURCE_DIR = path.join(ROOT, "data", "source-sheets");

const SOURCES = {
  social: {
    key: "google-sheet-social-listening",
    name: "Social listening post links",
    externalId: "1bdFZDsqJ_-g__ZsMRcTPswbCzP90FAfKwin7m6Gf9uo",
    file: path.join(SOURCE_DIR, "social-listening.xlsx"),
  },
  competitors: {
    key: "google-sheet-competitor-followers",
    name: "Weekly competitor follower tracker",
    externalId: "1t5PGAizug8ovvBB-QO3ygxJujHfnbDh6Bl7xf-KQgCc",
    file: path.join(SOURCE_DIR, "competitor-followers.xlsx"),
  },
  hopi: {
    key: "google-sheet-hopi-followers",
    name: "Hopi Hari daily follower log",
    externalId: "1vAZbigUr_iSzdWqhP79VnsEfwua6KPaIYud8hOfNecY",
    file: path.join(SOURCE_DIR, "hopi-followers.xlsx"),
  },
} as const;

const PLATFORM_NAMES: Record<string, string> = {
  instagram: "Instagram",
  tiktok: "TikTok",
  youtube: "YouTube",
  facebook: "Facebook",
  linkedin: "LinkedIn",
  x: "X",
};

function sha256(data: Buffer | string) {
  return crypto.createHash("sha256").update(data).digest("hex");
}

function slugify(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

function platformName(value: Cell) {
  const key = String(value ?? "").trim().toLowerCase();
  return PLATFORM_NAMES[key] ?? String(value ?? "").trim();
}

export function canonicalizeUrl(value: string) {
  const trimmed = value.trim();
  const url = new URL(trimmed);
  url.search = "";
  url.hash = "";
  url.hostname = url.hostname.toLowerCase();
  url.pathname = url.pathname.replace(/\/+$/, "") || "/";
  return url.toString();
}

function isoDate(value: Cell): string | null {
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value.toISOString().slice(0, 10);
  if (typeof value === "number") {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (parsed) return `${parsed.y}-${String(parsed.m).padStart(2, "0")}-${String(parsed.d).padStart(2, "0")}`;
  }
  const text = String(value ?? "").trim();
  const iso = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (iso) return `${iso[1]}-${iso[2]}-${iso[3]}`;
  const brazilian = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (brazilian) return `${brazilian[3]}-${brazilian[2]}-${brazilian[1]}`;
  return null;
}

function positiveInteger(value: Cell): number | null {
  if (value === null || value === undefined || value === "") return null;
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= 0 ? parsed : null;
}

function readRows(workbook: XLSX.WorkBook, sheetName: string): Row[] {
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) throw new Error(`Missing required sheet: ${sheetName}`);
  return XLSX.utils.sheet_to_json<Row>(sheet, { header: 1, raw: true, defval: null });
}

async function executeUpsert(connection: Connection, sql: string, values: unknown[]) {
  const [result] = await connection.execute<ResultSetHeader>(sql, values);
  return result.affectedRows === 1 ? "inserted" : result.affectedRows === 2 ? "updated" : "unchanged";
}

async function ensureSource(
  connection: Connection,
  source: (typeof SOURCES)[keyof typeof SOURCES],
) {
  await connection.execute(
    `INSERT INTO operational_sources
      (source_key, source_type, name, external_id, source_url)
     VALUES (?, 'google_sheet', ?, ?, ?)
     ON DUPLICATE KEY UPDATE name = VALUES(name), external_id = VALUES(external_id), source_url = VALUES(source_url), active = 1`,
    [source.key, source.name, source.externalId, `https://docs.google.com/spreadsheets/d/${source.externalId}/edit`],
  );
  const [rows] = await connection.execute<mysql.RowDataPacket[]>(
    "SELECT id FROM operational_sources WHERE source_key = ? LIMIT 1",
    [source.key],
  );
  return Number(rows[0].id);
}

async function beginRun(connection: Connection, sourceId: number, file: string) {
  const contentHash = sha256(fs.readFileSync(file));
  const [existing] = await connection.execute<mysql.RowDataPacket[]>(
    "SELECT id, status FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1",
    [sourceId, contentHash],
  );
  if (existing[0]?.status === "completed") return { id: Number(existing[0].id), contentHash, skipped: true };

  await connection.execute(
    `INSERT INTO operational_import_runs (source_id, content_hash, status)
     VALUES (?, ?, 'started')
     ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id), status = 'started', rows_seen = 0, rows_inserted = 0,
       rows_updated = 0, rows_rejected = 0, warnings_json = NULL, completed_at = NULL`,
    [sourceId, contentHash],
  );
  const [rows] = await connection.execute<mysql.RowDataPacket[]>(
    "SELECT id FROM operational_import_runs WHERE source_id = ? AND content_hash = ? LIMIT 1",
    [sourceId, contentHash],
  );
  return { id: Number(rows[0].id), contentHash, skipped: false };
}

async function finishRun(connection: Connection, runId: number, stats: ImportStats) {
  await connection.execute(
    `UPDATE operational_import_runs SET status = 'completed', rows_seen = ?, rows_inserted = ?, rows_updated = ?,
      rows_rejected = ?, warnings_json = ?, completed_at = NOW() WHERE id = ?`,
    [stats.rowsSeen, stats.rowsInserted, stats.rowsUpdated, stats.rowsRejected, JSON.stringify(stats.warnings), runId],
  );
}

function countOutcome(stats: ImportStats, outcome: string) {
  if (outcome === "inserted") stats.rowsInserted += 1;
  if (outcome === "updated") stats.rowsUpdated += 1;
}

async function ensureVenue(connection: Connection, name: string) {
  const slug = slugify(name);
  await connection.execute(
    `INSERT INTO social_venues (slug, name, is_hopi_hari) VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE name = VALUES(name), is_hopi_hari = VALUES(is_hopi_hari), active = 1`,
    [slug, name, name.trim().toLowerCase() === "hopi hari" ? 1 : 0],
  );
  const [rows] = await connection.execute<mysql.RowDataPacket[]>("SELECT id FROM social_venues WHERE slug = ? LIMIT 1", [slug]);
  return Number(rows[0].id);
}

async function ensureProfile(
  connection: Connection,
  venueId: number,
  platform: string,
  profileUrl: string | null,
  eligible: boolean,
) {
  await connection.execute(
    `INSERT INTO social_profiles (venue_id, platform, profile_url, eligible_for_index) VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE profile_url = COALESCE(VALUES(profile_url), profile_url), eligible_for_index = VALUES(eligible_for_index)`,
    [venueId, platform, profileUrl, eligible ? 1 : 0],
  );
  const [rows] = await connection.execute<mysql.RowDataPacket[]>(
    "SELECT id FROM social_profiles WHERE venue_id = ? AND platform = ? LIMIT 1",
    [venueId, platform],
  );
  return Number(rows[0].id);
}

async function importSocialLinks(connection: Connection, runId: number, file: string, stats: ImportStats) {
  const workbook = XLSX.readFile(file, { cellDates: true });
  for (const sheetName of workbook.SheetNames) {
    const platform = platformName(sheetName);
    const rows = readRows(workbook, sheetName);
    rows.forEach(() => {});
    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index];
      const rawUrl = sheetName === "X" ? row[0] : row[1];
      if (typeof rawUrl !== "string" || !/^\s*https?:\/\//i.test(rawUrl)) continue;
      stats.rowsSeen += 1;
      try {
        const canonicalUrl = canonicalizeUrl(rawUrl);
        const outcome = await executeUpsert(
          connection,
          `INSERT INTO social_content_links
            (platform, canonical_url_hash, canonical_url, original_url, source_label, source_order, source_run_id, source_sheet, source_row)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE canonical_url = VALUES(canonical_url), original_url = VALUES(original_url),
             source_label = VALUES(source_label), source_order = VALUES(source_order), source_run_id = VALUES(source_run_id),
             source_sheet = VALUES(source_sheet), source_row = VALUES(source_row)`,
          [
            platform,
            sha256(canonicalUrl),
            canonicalUrl,
            rawUrl.trim(),
            sheetName === "X" ? null : String(row[0] ?? "").trim() || null,
            index + 1,
            runId,
            sheetName,
            index + 1,
          ],
        );
        countOutcome(stats, outcome);
      } catch {
        stats.rowsRejected += 1;
        stats.warnings.push(`${sheetName}:${index + 1}:invalid_url`);
      }
    }
  }
}

async function importCompetitorFollowers(connection: Connection, runId: number, file: string, stats: ImportStats) {
  const workbook = XLSX.readFile(file, { cellDates: true });
  const rows = readRows(workbook, "COLETA");
  const dateHeaders = rows[3] ?? [];
  for (let rowIndex = 4; rowIndex < rows.length; rowIndex += 1) {
    const row = rows[rowIndex];
    const venueName = String(row[0] ?? "").trim();
    const platform = platformName(row[1]);
    if (!venueName || !platform) continue;
    const rawProfileUrl = typeof row[2] === "string" ? row[2].trim() : "";
    const profileUrl = /^https?:\/\//i.test(rawProfileUrl) ? canonicalizeUrl(rawProfileUrl) : null;
    const eligible = !(venueName === "Cacau Park" && platform === "LinkedIn");
    const venueId = await ensureVenue(connection, venueName);
    const profileId = await ensureProfile(connection, venueId, platform, profileUrl, eligible);

    for (let columnIndex = 3; columnIndex < dateHeaders.length; columnIndex += 1) {
      const observedDate = isoDate(dateHeaders[columnIndex]);
      const followerCount = positiveInteger(row[columnIndex]);
      if (!observedDate || followerCount === null) continue;
      stats.rowsSeen += 1;
      const outcome = await executeUpsert(
        connection,
        `INSERT INTO social_follower_snapshots
          (profile_id, observed_date, follower_count, source_run_id, source_sheet, source_row)
         VALUES (?, ?, ?, ?, 'COLETA', ?)
         ON DUPLICATE KEY UPDATE follower_count = VALUES(follower_count), source_run_id = VALUES(source_run_id),
           source_sheet = VALUES(source_sheet), source_row = VALUES(source_row)`,
        [profileId, observedDate, followerCount, runId, rowIndex + 1],
      );
      countOutcome(stats, outcome);
    }
  }
}

async function importHopiFollowers(connection: Connection, runId: number, file: string, stats: ImportStats) {
  const workbook = XLSX.readFile(file, { cellDates: true });
  const rows = readRows(workbook, "Log Diário");
  const platforms = ["Instagram", "TikTok", "Facebook", "YouTube", "LinkedIn"];
  const venueId = await ensureVenue(connection, "Hopi Hari");
  const profileIds = new Map<string, number>();
  for (const platform of platforms) {
    profileIds.set(platform, await ensureProfile(connection, venueId, platform, null, true));
  }

  let firstObservedDate: string | null = null;
  for (let rowIndex = 4; rowIndex < rows.length; rowIndex += 1) {
    const row = rows[rowIndex];
    const observedDate = isoDate(row[0]);
    if (!observedDate) continue;
    firstObservedDate ??= observedDate;
    for (let platformIndex = 0; platformIndex < platforms.length; platformIndex += 1) {
      const followerCount = positiveInteger(row[platformIndex + 1]);
      if (followerCount === null) continue;
      stats.rowsSeen += 1;
      const outcome = await executeUpsert(
        connection,
        `INSERT INTO social_follower_snapshots
          (profile_id, observed_date, follower_count, source_run_id, source_sheet, source_row)
         VALUES (?, ?, ?, ?, 'Log Diário', ?)
         ON DUPLICATE KEY UPDATE follower_count = VALUES(follower_count), source_run_id = VALUES(source_run_id),
           source_sheet = VALUES(source_sheet), source_row = VALUES(source_row)`,
        [profileIds.get(platforms[platformIndex]), observedDate, followerCount, runId, rowIndex + 1],
      );
      countOutcome(stats, outcome);
    }
  }

  const goalRows = readRows(workbook, "Meta 3M");
  const targetCount = positiveInteger(goalRows[3]?.[1]);
  if (targetCount !== null && firstObservedDate) {
    stats.rowsSeen += 1;
    const outcome = await executeUpsert(
      connection,
      `INSERT INTO social_audience_goals (goal_key, effective_from, target_count, source_run_id)
       VALUES ('total-followers', ?, ?, ?)
       ON DUPLICATE KEY UPDATE target_count = VALUES(target_count), source_run_id = VALUES(source_run_id)`,
      [firstObservedDate, targetCount, runId],
    );
    countOutcome(stats, outcome);
  }
}

async function importOne(
  connection: Connection,
  source: (typeof SOURCES)[keyof typeof SOURCES],
  importer: (connection: Connection, runId: number, file: string, stats: ImportStats) => Promise<void>,
) {
  const sourceId = await ensureSource(connection, source);
  const run = await beginRun(connection, sourceId, source.file);
  const stats: ImportStats = {
    sourceKey: source.key,
    status: run.skipped ? "skipped" : "completed",
    rowsSeen: 0,
    rowsInserted: 0,
    rowsUpdated: 0,
    rowsRejected: 0,
    warnings: [],
  };
  if (run.skipped) return stats;

  await connection.beginTransaction();
  try {
    await importer(connection, run.id, source.file, stats);
    await connection.commit();
    await finishRun(connection, run.id, stats);
    return stats;
  } catch (error) {
    await connection.rollback();
    const safeMessage = error instanceof Error ? error.message.slice(0, 500) : "unknown_import_error";
    await connection.execute(
      "UPDATE operational_import_runs SET status = 'failed', warnings_json = ?, completed_at = NOW() WHERE id = ?",
      [JSON.stringify([safeMessage]), run.id],
    );
    throw error;
  }
}

async function main() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  for (const source of Object.values(SOURCES)) {
    if (!fs.existsSync(source.file)) throw new Error(`Missing source export: ${path.basename(source.file)}`);
  }

  const connection = await mysql.createConnection(process.env.DATABASE_URL);
  try {
    const results = [];
    results.push(await importOne(connection, SOURCES.social, importSocialLinks));
    results.push(await importOne(connection, SOURCES.competitors, importCompetitorFollowers));
    results.push(await importOne(connection, SOURCES.hopi, importHopiFollowers));
    console.log(JSON.stringify({ imports: results }, null, 2));
  } finally {
    await connection.end();
  }
}

await main();
