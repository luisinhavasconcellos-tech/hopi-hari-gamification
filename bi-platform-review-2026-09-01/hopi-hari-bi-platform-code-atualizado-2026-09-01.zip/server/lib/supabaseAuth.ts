import { createClient } from "@supabase/supabase-js";
import type { Request } from "express";
import { getOrCreatePlatformAccess } from "../db";

const AUTH_SUPABASE_URL =
  process.env.AUTH_SUPABASE_URL || "https://afqidjbyfrhtxheenhhp.supabase.co";
const AUTH_SUPABASE_ANON_KEY =
  process.env.AUTH_SUPABASE_ANON_KEY || "sb_publishable_xZJHFC98c2Zf7WBcdSEV5g_bAGW8iSb";

export class ApiAuthError extends Error {
  constructor(
    public readonly status: number,
    message: string,
  ) {
    super(message);
  }
}

export async function resolveSupabaseUserAccess(req: Request) {
  const authorization = req.headers.authorization;
  const token = typeof authorization === "string" && authorization.startsWith("Bearer ")
    ? authorization.slice(7).trim()
    : "";
  if (!token) throw new ApiAuthError(401, "Authentication required");

  const publicClient = createClient(AUTH_SUPABASE_URL, AUTH_SUPABASE_ANON_KEY, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data: userData, error: userError } = await publicClient.auth.getUser(token);
  if (userError || !userData.user) throw new ApiAuthError(401, "Invalid or expired session");
  const email = userData.user.email?.trim().toLowerCase();
  if (!email) throw new ApiAuthError(403, "An email address is required");
  const fullName =
    typeof userData.user.user_metadata?.full_name === "string"
      ? userData.user.user_metadata.full_name
      : null;
  const access = await getOrCreatePlatformAccess(email, fullName);
  if (!access) throw new ApiAuthError(503, "Unable to verify platform access");

  return {
    id: userData.user.id,
    email,
    status: access.status,
    role: access.role,
  } as const;
}

export async function authenticateApprovedSupabaseUser(req: Request) {
  const access = await resolveSupabaseUserAccess(req);
  if (access.status !== "approved") throw new ApiAuthError(403, "Account approval required");
  return access;
}
