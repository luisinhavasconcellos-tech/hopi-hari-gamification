import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";
import { authenticateApprovedSupabaseUser } from "../lib/supabaseAuth";
import { sdk } from "./sdk";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

export async function createContext(
  opts: CreateExpressContextOptions
): Promise<TrpcContext> {
  let user: User | null = null;

  try {
    user = await sdk.authenticateRequest(opts.req);
  } catch {
    try {
      const access = await authenticateApprovedSupabaseUser(opts.req);
      const now = new Date();
      user = {
        id: -1,
        openId: `supabase:${access.id}`,
        name: access.email,
        email: access.email,
        loginMethod: "supabase",
        role: access.role === "admin" ? "admin" : "user",
        createdAt: now,
        updatedAt: now,
        lastSignedIn: now,
      };
    } catch {
      // Authentication is optional for public procedures.
      user = null;
    }
  }

  return {
    req: opts.req,
    res: opts.res,
    user,
  };
}
