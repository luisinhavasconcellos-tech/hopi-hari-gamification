import type { Express, Response } from "express";
import { getOperationalSummary } from "../lib/operationalSummary";
import { ApiAuthError, authenticateApprovedSupabaseUser } from "../lib/supabaseAuth";

function sendError(res: Response, error: unknown) {
  if (error instanceof ApiAuthError) return res.status(error.status).json({ error: error.message });
  console.error("[Operational Summary]", error);
  return res.status(500).json({ error: "Operational data is temporarily unavailable" });
}

export function registerOperationalRoutes(app: Express) {
  app.get("/api/operational/summary", async (req, res) => {
    try {
      await authenticateApprovedSupabaseUser(req);
      return res.json({ summary: await getOperationalSummary() });
    } catch (error) {
      return sendError(res, error);
    }
  });
}
