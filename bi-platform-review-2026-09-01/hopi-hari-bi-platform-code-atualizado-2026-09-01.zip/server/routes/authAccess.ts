import type { Express } from "express";
import { ApiAuthError, resolveSupabaseUserAccess } from "../lib/supabaseAuth";

export function registerAuthAccessRoutes(app: Express) {
  app.get("/api/auth/access", async (req, res) => {
    try {
      const access = await resolveSupabaseUserAccess(req);
      res.json({
        status: access.status,
        roles: [access.role],
      });
    } catch (error) {
      const status = error instanceof ApiAuthError ? error.status : 500;
      const message = error instanceof Error ? error.message : "Unable to verify platform access";
      res.status(status).json({ error: message });
    }
  });
}
